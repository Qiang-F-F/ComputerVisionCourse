main.m is for sequence 1
main_2.m is for sequence 2
