please run main.m, rectify.m, reconstruct.m in sequence.
